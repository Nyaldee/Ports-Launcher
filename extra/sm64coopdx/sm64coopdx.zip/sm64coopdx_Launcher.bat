@echo off
setlocal EnableExtensions
color 0C
mode con cols=90 lines=35

cd /d "%~dp0"
set "ROOT=%~dp0"

:: Detecte l'executable dans le dossier -- sm64coopdx.exe en priorite,
:: sinon un sm64coop*.exe au cas ou le nom du build differe.
set "EXE="
if exist "%ROOT%sm64coopdx.exe" set "EXE=%ROOT%sm64coopdx.exe"
if not defined EXE for %%F in ("%ROOT%sm64coop*.exe") do if not defined EXE set "EXE=%%~fF"

if not defined EXE (
    cls
    echo.
    echo ============================================================
    echo   sm64coopdx for Ports Launcher
    echo ============================================================
    echo.
    echo ERROR: sm64coopdx.exe not found in this folder.
    echo.
    pause
    exit 1
)

:: Saves portables : equivaut au raccourci "--savepath .\saves".
:: cd deja fait sur %~dp0, donc .\saves pointe bien sur ce dossier.
if not exist "%ROOT%saves" mkdir "%ROOT%saves"

cls
echo.
echo ============================================================
echo   sm64coopdx for Ports Launcher
echo ============================================================
echo.
echo Launching sm64coopdx with portable saves ( .\saves )...
echo.

:: Processus detache -- cette fenetre peut se fermer des que le jeu demarre.
start "" "%EXE%" --savepath ".\saves"
exit 0
